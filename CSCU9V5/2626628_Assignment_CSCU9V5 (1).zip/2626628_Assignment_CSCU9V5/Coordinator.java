import java.net.*;

public class Coordinator {

    public static void main(String args[]) {

        int port = 7000;
        //Created a class level C_buffer object
        C_buffer buffer = new C_buffer();

        Coordinator c = new Coordinator();

        try {
            InetAddress c_addr = InetAddress.getLocalHost();
            String c_name = c_addr.getHostName();
            System.out.println("Coordinator: Coordinator address is " + c_addr);
            System.out.println("Coordinator: Coordinator host name is " + c_name + "\n\n");
        } catch (Exception e) {
            System.err.println(e);
            System.err.println("Coordinator: Error in corrdinator");
        }

        // override default port with user input
        if (args.length == 1) {
            port = Integer.parseInt(args[0]);
        }

        // Create and run a C_receiver and a C_mutex object sharing a C_buffer object
        Thread receiver = new C_receiver(buffer, port);
        //Starting the receiver thread
        receiver.start();
        System.out.println("Coordinator:  receiver has started");

        Thread mutex = new C_mutex(buffer, port);
        //Starting the mutex thread
        mutex.start();
        System.out.println("Coordinator:  mutex has started");
    }
}
