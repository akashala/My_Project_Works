import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;

/**
 * Class that fetches request from buffer in FIFO.
 * This sends the token to client and wait for it to return.
 */
public class C_mutex extends Thread {


    private Random ra = new Random();

    C_buffer buffer;
    Socket client;
    int port;

    //ip address and port number of the node requesting the token.
    //They will be fetched from the buffer
    String n_host;
    int n_port;

    ObjectOutputStream outputStream;
    ObjectInputStream inputStream;

    //Integer token that is passed to Node
    int token;


    public C_mutex(C_buffer buffer, int port) {
        this.buffer = buffer;
        this.port = port;
    }

    public void go() {

        try {
            // Listening from the server socket on port 7001
            // from where the TOKEN will be later on returned.
            // This place the server creation outside the while loop.
            ServerSocket server = new ServerSocket(7001);

            while (true) {

                // if the buffer is not empty
                if (buffer.size() > 0) {

                    String[] request;
                    // Getting the first (FIFO) node that is waiting for a TOKEN form the buffer
                    // Type conversions may be needed.
                    Thread.sleep(3 * 1000);
                    request = (String[]) buffer.get();

                    n_host = request[0];
                    n_port = Integer.parseInt(request[1]);
                    System.out.println("C_mutex:  Fetched details from buffer " + n_host + ":" + n_port);

                    //Granting the token
                    try {
                        System.out.println("C_mutex: opening socket on port: " + n_port + " to send token");
                        client = new Socket(n_host, n_port);

                        outputStream = new ObjectOutputStream(client.getOutputStream());

                        token = ra.nextInt();
                        outputStream.writeObject(token);
                        System.out.println("C_mutex:  token sent: " + token);
                    } catch (java.io.IOException e) {
                        System.err.println(e);
                        System.err.println("C_mutex: CRASH Mutex connecting to the node for granting the TOKEN" + e);
                    }

                    //Getting the token back
                    try {
                        client = server.accept();
                        System.out.println("C_mutex: Client accepted: " + client);

                        inputStream = new ObjectInputStream(client.getInputStream());
                        int tokenReceived = (Integer) inputStream.readObject();
                        System.out.println("C_mutex: Have you received same token: " + (tokenReceived == token));
                        System.out.println("C_mutex: Token sent is returned: " + tokenReceived);
                    } catch (java.io.IOException e) {
                        System.err.println(e);
                        System.err.println("C_mutex: CRASH Mutex waiting for the TOKEN back" + e);
                    }

                }// endif
            }// endwhile
        } catch (Exception e) {
            System.err.print(e);
        }
    }

    public void run() {
        go();
    }
}
