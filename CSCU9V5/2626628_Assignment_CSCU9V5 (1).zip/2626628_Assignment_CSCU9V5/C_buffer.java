import java.util.*;

public class C_buffer {

    private Vector<Object> data;


    public C_buffer() {
        data = new Vector<Object>();
    }


    /**
     * Thread safe method to store the request
     *
     * @param request
     */
    public synchronized void saveRequest(String[] request) {
        data.add(request[0]); //ip
        data.add(request[1]); //port
        data.add(request[2]); //priority
    }


    /**
     * Thread safe method to return first object in data structure
     *
     * @return
     */
    synchronized public Object get() {

        Object obj = null;

        int key = 0;
        int index = 0;
        String[] str = new String[3];
        //Looping though the buffer data and getting the the high priority Node index
        for (int i = 0; i < data.size(); i++) {
            str = (String[]) data.get(0);
            int curPriority = Integer.parseInt(str[2]);
            if (curPriority > key) {
                key = curPriority;
                index = i;
                System.out.println(String.format("C_buffer: Highest priority of the Node %s, index of Node: %s", key, index));
            }
        }

        if (data.size() > 0) {
            obj = data.get(index);
            data.remove(index);
        }

        System.out.println("C_buffer: Object fetched from buffer: " + str[0] + ":" + str[1] + ":" + str[2]);
        return obj;
    }

    /**
     * To store obj in buffer
     *
     * @param obj
     */
    public void add(Object obj) {
        data.add(obj);
    }


    /**
     * To show objects in buffer
     */
    public void show() {

        if (data == null
                || data.size() == 0) {
            System.out.println("C_buffer: There are no object in buffer");
            return;
        }

        for (int i = 0; i < data.size(); i++) {
            String[] str = (String[]) data.get(i);
            System.out.print("C_buffer: " + i + "# " + str[0] + ":" + str[1]);
        }

        System.out.println(" ");
    }

    /**
     * Method to return the buffer size
     *
     * @return
     */
    public int size() {
        return data.size();
    }
}


