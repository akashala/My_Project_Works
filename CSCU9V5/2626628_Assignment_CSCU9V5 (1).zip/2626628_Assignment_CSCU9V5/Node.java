import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Date;

public class Node {


    private ServerSocket server;
    private Socket client;


    String c_host = "127.0.0.1";
    final int c_request_port = 7000;
    final int c_return_port = 7001;

    String n_host = "127.0.0.1";
    String n_host_name;
    int n_port;

    ObjectOutputStream outputStream;
    ObjectInputStream inputStream;
    int token = 0;

    public Node(String name, int port, int sec, int priority) throws InterruptedException, UnknownHostException, IOException, ClassNotFoundException {

        n_host_name = name;
        n_port = port;
        System.out.println("Node: Node " + n_host_name + ":" + n_port + " of DME is active ....");

        while (true) {

            //Sleep a random number of seconds linked to the initialisation sec value
            Thread.sleep(sec * 1000);

            try {
                //Send to the coordinator a token request.
                //sending your ip address and port number
                client = new Socket(n_host_name, c_request_port, InetAddress.getLocalHost(), port);
                System.out.println("Node: Opened socket to requesting Coordinator for token on port 7000");

                outputStream = new ObjectOutputStream(client.getOutputStream());
                //Priority of the node is passed via outputStream
                outputStream.writeObject(priority);
                outputStream.close();

                //Wait for the token
                //this is just a synchronization
                // Print suitable messages
                synchronized (this) {
                    System.out.println(new Date() + ":Node: Listening for token from C_Mutex on port: " + port);
                    server = new ServerSocket(port);

                    client = server.accept();
                    System.out.println("Node: Client accepted: " + client);

                    inputStream = new ObjectInputStream(client.getInputStream());
                    token = (Integer) inputStream.readObject();
                    System.out.println("Node: Token received: " + token);
                    client.close();
                }


                // Sleep half a second, say
                // This is the critical session
                System.out.println("Node: Started executing critical section");
                Thread.sleep(3 * 1000);//this is where we do critical processing
                System.out.println("Node: Finished critical section");


                //Return the token
                // this is just establishing a synch connection to the coordinator's ip and return port.
                // Print suitable messages - also considering communication failures
                client = new Socket(n_host_name, c_return_port); //"127.0.0.1:7001"
                System.out.println("Node: opened socket on port: " + c_return_port + " to return token");

                outputStream = new ObjectOutputStream(client.getOutputStream());
                outputStream.writeObject(token);
                System.out.println("Node: token returned");

                inputStream.close();
                outputStream.close();
                server.close();
                client.close();

                break;
            } catch (java.io.IOException e) {
                System.out.println(e);
                System.exit(1);
            }
        }
    }

    public static void main(String args[]) throws NumberFormatException, InterruptedException, UnknownHostException, IOException, ClassNotFoundException {

        String n_host_name = "";
        int n_port;

        //Port and milli seconds program arguments must be passed to run the Node class
      //TPriority of the Node is also passed as argument here
        if ((args.length < 2) || (args.length > 3)) {
            System.out.print("Node: Usage: Node [port number], [millisecs], [priority]");
            System.exit(1);
        }

        //Get the IP address and the port number of the node
        try {
            InetAddress n_inet_address = InetAddress.getLocalHost();
            n_host_name = n_inet_address.getHostName();
            System.out.println("Node: node hostname is " + n_host_name + ":" + n_inet_address);
        } catch (java.net.UnknownHostException e) {
            System.out.println(e);
            System.exit(1);
        }

        n_port = Integer.parseInt(args[0]);
        System.out.println("Node: node port is " + n_port);
        // Creating the node using the constructor
      //priority also passed to the constructor
        Node n = new Node(n_host_name, n_port, Integer.parseInt(args[1]), Integer.parseInt(args[2]));
    }
}

