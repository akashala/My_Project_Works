import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class C_receiver extends Thread {

    private C_buffer buffer;
    private int port;

    private ServerSocket server;
    private Socket client;

    private C_Connection_r connection;


    public C_receiver(C_buffer buffer, int port) {
        this.buffer = buffer;
        this.port = port;
        System.out.println("C_receiver: started with port: " + port);
    }


    public void run() {

        //Create the socket the server will listen to
        try {
            server = new ServerSocket(7000);
        } catch (IOException e1) {
            System.err.println("C_receiver: Error in listening on port 7000");
            e1.printStackTrace();
            System.exit(1);
        }

        while (true) {
            try {
                //Get a new connection
                client = server.accept();
                System.out.println("C_receiver:  Coordinator has received a request from node: " + client);

                // Create a separate thread to service the request, a C_Connection_r thread.
                connection = new C_Connection_r(client, buffer);
                connection.start();
            } catch (java.io.IOException e) {
                System.out.println("C_receiver: Exception when creating a connection " + e);
            }
        }
    }//end run
}


