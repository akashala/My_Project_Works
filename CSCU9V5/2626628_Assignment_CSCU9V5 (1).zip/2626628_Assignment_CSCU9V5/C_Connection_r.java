import java.io.*;
import java.net.Socket;


/**
 * Class that acts on node request.
 * It receives and store the node request in the buffer
 */
public class C_Connection_r extends Thread {

    // class variables
    C_buffer buffer;

    Socket client;

    public C_Connection_r(Socket client, C_buffer buffer) {
        this.client = client;
        this.buffer = buffer;
    }

    @Override
    public void run() {

        final int NODE = 0;
        final int PORT = 1;
        final int PRIORITY = 2;

        String[] request = new String[3];

        System.out.println("C_connection: IN  connection in dealing with request from socket " + client);

        try {

            // read the request, i.e. node ip and port from the socket s
            // save it in a request object and save the object in the buffer (see C_buffer's methods)
            // assign node ip address and port details to request string array
            request[NODE] = client.getInetAddress().getHostAddress();
            request[PORT] = Integer.toString(client.getPort());

            System.out.println("C_connection:  storing request: " + request[NODE] + ":" + request[PORT] + ":" + request[PRIORITY]);
            ObjectInputStream inputStream = new ObjectInputStream(client.getInputStream());
            //reading the priority of the Node
            request[PRIORITY] = String.valueOf(inputStream.readObject());
            // store request in the buffer
            buffer.add(request);

            client.close();
            System.out.println("C_connection: OUT    received and recorded request from " + request[NODE] + ":" + request[PORT] + "  (socket closed)");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e);
            System.exit(1);
        }

        buffer.show();
    } // end of run() method
} // end of class
