/* 
 * File:   main.c
 * Author: Akash Ala
 *
 * Created on 05 April 2019, 10:41
 */

#include <windows.h>
#include <stdio.h>

int main() {
    boolean cont = 1;
    DWORD mode;
    INPUT_RECORD event;
    BOOL done = FALSE;

    HANDLE hstdin;
    printf("Enter buttons: 1, 2, 3, 4 or (5 to exit)");
    while (!done) {
        hstdin = GetStdHandle(STD_INPUT_HANDLE);

        GetConsoleMode(hstdin, &mode);

        SetConsoleMode(hstdin, 0);

        if (WaitForSingleObject(hstdin, 1000) == WAIT_OBJECT_0) {
            DWORD count;
            ReadConsoleInput(hstdin, &event, 1, &count);
            boolean one = FALSE;
            boolean two = FALSE;
            boolean three = FALSE;
            boolean four = FALSE;
            if ((event.EventType == KEY_EVENT) && !event.Event.KeyEvent.bKeyDown) {
                if (GetAsyncKeyState(0x31)) {
                    one = TRUE;

                }
                if (GetAsyncKeyState(0x32)) {
                    two = TRUE;
                }
                if (GetAsyncKeyState(0x33)) {
                    three = TRUE;
                }
                if (GetAsyncKeyState(0x34)) {
                    four = TRUE;
                }
                if (one && !two && !three && !four) {

                    printf("move left (L)\n");
                    printf("  *\n");
                    printf(" *\n");
                    printf("**************\n");
                    printf(" *\n");
                    printf("  *\n");
                }


                if (!one && two && !three && !four) {
                    printf("rotate anti-clockwise (ACW)\n");
                    printf("  *\n");
                    printf(" *\n");
                    printf("*********\n");
                    printf(" *     *\n");
                    printf("  *   *\n");
                    printf("     *\n");
                    printf("    *\n");
                }
                if (!one && !two && three && !four) {

                    printf("move right (R)\n");
                    printf("      *\n");
                    printf("       *\n");
                    printf("**********\n");
                    printf("       *\n");
                    printf("      *\n");
                }
                if (!one && !two && !three && four) {

                    printf("rotate clockwise (CW)\n");
                    printf("      *\n");
                    printf("       *\n");
                    printf(" ********\n");
                    printf(" *      *\n");
                    printf("  *    *\n");
                    printf("   *\n");
                    printf("    *\n");
                }

                if (one && two && !three && !four) {
                    printf("down\n");
                    printf("   *\n");
                    printf("   *\n");
                    printf("*******\n");
                    printf("  ***\n");
                    printf("   *\n");
                }

                if (one && !two && !three && four) {

                    printf("move up (U)\n");
                    printf("   *\n");
                    printf("  ***\n");
                    printf("*******\n");
                    printf("   *\n");
                    printf("   *\n");
                }


                if (one && !two && three && !four) {
                    printf("rotate anticlockwise (ACW) & move left (L) simultaneously\n");
                    printf("             *     |           *\n");
                    printf("           *       |          *\n");
                    printf("         ********* |        ************\n");
                    printf("          *       *|         *\n");
                    printf("           *     * |          *\n");
                    printf("                *  |\n");
                    printf("               *   |\n");
                }

                if (!one && two && !three && four) {

                    printf("rotate clockwise (CW) & move left (L) simultaneously\n");
                    printf("                       *       |      *\n");
                    printf("                        *      |     *\n");
                    printf("               *  * ********   |    **************\n");
                    printf("              *          *     |     *\n");
                    printf("               *        *      |      *\n");
                    printf("                *              | \n");
                    printf("                 *             | \n");
                }

                if (!one && two && three && !four) {

                    printf("rotate anti-clockwise (ACW) & move right (R) simultaneously\n");
                    printf("     *              |           *\n");
                    printf("    *               |            *\n");
                    printf("   *********        |     *********\n");
                    printf("    *       *       |            *\n");
                    printf("     *     *        |           *\n");
                    printf("          *         | \n");
                    printf("         *          | \n");
                }

                if (!one && !two && three && four) {
                    printf("rotate clockwise (CW) & move right (R) simultaneously\n");
                    printf("                      *      |         *\n");
                    printf("                       *     |          *\n");
                    printf("             *  * ********   |   *********\n");
                    printf("             *          *    |           *\n");
                    printf("              *        *     |          *\n");
                    printf("               *             | \n");
                    printf("                *            | \n");
                }
                if (one && two && three && !four) {
                    printf("rotate anticlockwise (ACW) & move down (D) simultaneously\n");
                    printf("   *            |     *\n");
                    printf("  *             |     *\n");
                    printf(" *********      |  *******\n");
                    printf("  *       *     |    ***\n");
                    printf("   *     *      |     *\n");
                    printf("        *       | \n");
                    printf("       *        | \n");
                }

                if (one && !two && three && four) {
                    printf("rotate anticlockwise (ACW) & move up (U) simultaneously\n");
                    printf("   *           |       *\n");
                    printf("  *            |      ***\n");
                    printf(" *********     |    *******\n");
                    printf("  *       *    |       *\n");
                    printf("   *     *     |       *\n");
                    printf("        *      | \n");
                    printf("       *       | \n");
                }

                if (one && two && !three && four) {

                    printf("rotate clockwise (CW) & move down (D) simultaneously\n");
                    printf("                  *     |         *\n");
                    printf("                   *    |         *\n");
                    printf("        *  * ********   |      *******\n");
                    printf("       *          *     |        ***\n");
                    printf("        *        *      |         *\n");
                    printf("         *              |  \n");
                    printf("           *            |  \n");
                }

                if (!one && two && three && four) {

                    printf("rotate clockwise (CW) & move up (U) simultaneously\n");
                    printf("                 *     |          *\n");
                    printf("                  *    |         ***\n");
                    printf("       *  * ********   |       *******\n");
                    printf("       *          *    |          *\n");
                    printf("        *        *     |          *\n");
                    printf("         *             | \n");
                    printf("          *            | \n");
                }

                if (one && two && three && four) {
                    printf("nothing happens!\n");
                }

                if (GetAsyncKeyState(0x35)) {
                    printf("exit");
                    done = TRUE;
                }
            }
        }
    }
    SetConsoleMode(hstdin, mode);
    return 0;
}