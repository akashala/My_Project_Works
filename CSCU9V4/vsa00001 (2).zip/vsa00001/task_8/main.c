/* 
 * File:   main.c
 * Author: Akash Ala
 *
 * Created on 05 April 2019, 10:52
 */

#include<stdio.h>
#include<stdbool.h>
#include <stdlib.h>
#include <memory.h>


int main() {
    printf("Enter input as 0 or 1 values for A, B, C, D :");
    while (1) {
        char input[5] = {'0', '0', '0', '0', '0'};
        fgets(input, 5, stdin);
        bool a = false, aNot = true, b = false, bNot = true, c = false, cNot = true, d = false, dNot = true;

        if (input[0] == '1') a = true, aNot = false;
        if (input[1] == '1') b = true, bNot = false;
        if (input[2] == '1') c = true, cNot = false;
        if (input[3] == '1') d = true, dNot = false;

        bool cw = (aNot && bNot && cNot && d) + (aNot && b && cNot && d) + (aNot && bNot && c && d) +
                  (a && b && cNot && d) + (aNot && b && c && d);
        bool acw = (aNot && b && cNot && dNot) + (a && bNot && c && dNot) + (aNot && b && c && dNot) +
                   (a && b && c && dNot) + (a && bNot && c && d);
        bool left = (a && bNot && cNot && dNot) + (a && bNot && c && dNot) + (aNot && b && cNot && d);
        bool right = (aNot && bNot && c && dNot) + (aNot && b && c && dNot) + (aNot && bNot && c && d);
        bool up =
                (aNot && bNot && cNot && d) + (a && bNot && cNot && d) + (a && bNot && c && d) + (aNot && b && c && d);
        bool down =
                (aNot && b && cNot && dNot) + (a && b && cNot && dNot) + (a && b && c && dNot) + (a && b && cNot && d);

        printf("\nCW value: %d", cw);
        printf("\nACW value: %d", acw);
        printf("\nL value: %d", left);
        printf("\nR value: %d", right);
        printf("\nU value: %d", up);
        printf("\nD value: %d", down);


        if (left && !right && !cw && !acw && !up & !down) {
            printf("\nmove left (L)\n");
            printf("  *\n");
            printf(" *\n");
            printf("**************\n");
            printf(" *\n");
            printf("  *\n");
        }
        if (acw && !left && !right && !cw && !up && !down) {
            printf("\nrotate anti-clockwise (ACW)\n");
            printf("  *\n");
            printf(" *\n");
            printf("*********\n");
            printf(" *     *\n");
            printf("  *   *\n");
            printf("     *\n");
            printf("    *\n");
        }
        if (right && !cw && !acw && !left && !up && !down) {
            printf("\nmove right (R)\n");
            printf("      *\n");
            printf("       *\n");
            printf("**********\n");
            printf("       *\n");
            printf("      *\n");
        }
        if (cw && !acw && !left && !right && !up && !down) {
            printf("\nrotate clockwise (CW)\n");
            printf("      *\n");
            printf("       *\n");
            printf(" ********\n");
            printf(" *      *\n");
            printf("  *    *\n");
            printf("   *\n");
            printf("    *\n");
        }
        if (down && !acw && !left && !right && !cw && !up) {
            printf("\nmove down (D)\n");
            printf("   *\n");
            printf("   *\n");
            printf("*******\n");
            printf("  ***\n");
            printf("   *\n");
        }
        if (up && !acw && !left && !right && !cw && !down) {
            printf("\nmove up (U)\n");
            printf("   *\n");
            printf("  ***\n");
            printf("*******\n");
            printf("   *\n");
            printf("   *\n");
        }
        if ((acw && left && !right && !cw && !up && !down)) {
            printf("\nrotate anticlockwise (ACW) & move left (L) simultaneously\n");
            printf("             *     |           *\n");
            printf("           *       |          *\n");
            printf("         ********* |        ************\n");
            printf("          *       *|         *\n");
            printf("           *     * |          *\n");
            printf("                *  |\n");
            printf("               *   |\n");
        }
        if (cw && left && !right && !acw && !up && !down) {
            printf("\nrotate clockwise (CW) & move left (L) simultaneously\n");
            printf("                       *       |      *\n");
            printf("                        *      |     *\n");
            printf("               *  * ********   |    **************\n");
            printf("              *          *     |     *\n");
            printf("               *        *      |      *\n");
            printf("                *              | \n");
            printf("                 *             | \n");
        }
        if (acw && right && !left && !cw && !up && !down) {
            printf("\nrotate anti-clockwise (ACW) & move right (R) simultaneously\n");
            printf("     *              |           *\n");
            printf("    *               |            *\n");
            printf("   *********        |     *********\n");
            printf("    *       *       |            *\n");
            printf("     *     *        |           *\n");
            printf("          *         | \n");
            printf("         *          | \n");
        }
        if (cw && right && !left && !acw && !up && !down) {
            printf("\nrotate clockwise (CW) & move right (R) simultaneously\n");
            printf("                      *      |         *\n");
            printf("                       *     |          *\n");
            printf("             *  * ********   |   *********\n");
            printf("             *          *    |           *\n");
            printf("              *        *     |          *\n");
            printf("               *             | \n");
            printf("                *            | \n");
        }
        if (acw && down && !right && !cw && !up && !left) {
            printf("\nrotate anticlockwise (ACW) & move down (D) simultaneously\n");
            printf("   *            |     *\n");
            printf("  *             |     *\n");
            printf(" *********      |  *******\n");
            printf("  *       *     |    ***\n");
            printf("   *     *      |     *\n");
            printf("        *       | \n");
            printf("       *        | \n");
        }
        if (acw && up && !right && !cw && !left && !down) {
            printf("\nrotate anticlockwise (ACW) & move up (U) simultaneously\n");
            printf("   *           |       *\n");
            printf("  *            |      ***\n");
            printf(" *********     |    *******\n");
            printf("  *       *    |       *\n");
            printf("   *     *     |       *\n");
            printf("        *      | \n");
            printf("       *       | \n");
        }
        if (cw && down && !right && !acw && !up && !left) {
            printf("\nrotate clockwise (CW) & move down (D) simultaneously \n");
            printf("                  *     |         *\n");
            printf("                   *    |         *\n");
            printf("        *  * ********   |      *******\n");
            printf("       *          *     |        ***\n");
            printf("        *        *      |         *\n");
            printf("         *              |  \n");
            printf("           *            |  \n");
        }
        if (cw && up && !right && !acw && !left && !down) {
            printf("\nrotate clockwise (CW) & move up (U) simultaneously\n");
            printf("                 *     |          *\n");
            printf("                  *    |         ***\n");
            printf("       *  * ********   |       *******\n");
            printf("       *          *    |          *\n");
            printf("        *        *     |          *\n");
            printf("         *             | \n");
            printf("          *            | \n");
        }
        if ((cw == true && acw == true && left == true && right == true && up == true && down == true) ||
            (cw == false && acw == false && left == false && right == false && up == false && down == false)) {
            printf("\nnothing happens!");
        }

        return 0;
    }
}