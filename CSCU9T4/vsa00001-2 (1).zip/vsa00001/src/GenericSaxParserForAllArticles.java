
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class GenericSaxParserForAllArticles {

    static String egPath = "http://www.cs.stir.ac.uk/~rcc/xml_egs/news/reutersAll.xml";

    public static void main(String[] a) throws ParserConfigurationException,
            SAXException, IOException {

        SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.setNamespaceAware(true);
        SAXParser sp = spf.newSAXParser();
        URL url = new URL(egPath);
        InputStream is = url.openStream();
        final DefaultHandler dh = new DefaultHandler() {
            boolean inName = false;
            boolean inParagraphTag = false;
            int count = 0;

            @Override
            public void startDocument() throws SAXException {
                System.out.println("*********************** Started parsing the document ************************");
            }

            @Override
            public void startElement(String uri, String localName,
                                     String qName, Attributes attributes) throws SAXException {
                if (localName.equals("p")) {
                    inParagraphTag = true;
                }
                if (localName.equals("byline")) {
                    inName = true;
                }
            }

            @Override
            public void characters(char[] ch, int start, int length) throws SAXException {
                if (inParagraphTag) {
                    if (String.valueOf(ch, start, length).contains("Henry Tricks")) {
                        this.count++;
                    }
                }
            }

            @Override
            public void endElement(String uri, String localName, String qName)
                    throws SAXException {
                if (localName.equals("byline")) {
                    inName = false;
                    inParagraphTag = false;
                }
            }

            @Override
            public void endDocument() throws SAXException {
                System.out.println(String.format("\nParsed the document, There are %s articles written by Henry Tricks", this.count));
            }
        };

        sp.parse(is, dh);
        is.close();
    }
}