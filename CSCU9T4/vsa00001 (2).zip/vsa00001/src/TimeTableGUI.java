import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class TimeTableGUI extends JFrame implements ActionListener {

    private JTextField name = new JTextField(10);
    private JTextField day = new JTextField(10);
    private JTextField startTime = new JTextField(10);
    private JTextField endTime = new JTextField(10);
    private JTextField weekPattern = new JTextField(10);
    private JTextField location = new JTextField(10);
    private JTextField roomSize = new JTextField(10);
    private JTextField classSize = new JTextField(10);
    private JTextField staff = new JTextField(10);
    private JTextField department = new JTextField(10);

    private JLabel labn = new JLabel(" Module Name:");
    private JLabel labd = new JLabel(" Day:");
    private JLabel labsT = new JLabel(" StartTime:");
    private JLabel labeT = new JLabel(" EndTime:");
    private JLabel labwP = new JLabel(" WeekPattern:");
    private JLabel labl = new JLabel(" Location:");
    private JLabel labrS = new JLabel(" RoomSize:");
    private JLabel labcS = new JLabel("ClassSize");
    private JLabel labs = new JLabel("Staff");
    private JLabel labdep = new JLabel("Department");

    private JButton lookup = new JButton("LookUp");
    private JButton add = new JButton("Add");
    private JButton remove = new JButton("Remove");
    private JButton update = new JButton("Update");
    private JButton writeToFile = new JButton("Write to output file");
    private JButton writeToHTMLFile = new JButton("Write to HTML output file");

    private TimeTable timeTable;
    private JTextArea outputArea; // Text area
    private JScrollPane scrollbar; // Scroll pane for text area

    public static void main(String[] args) throws IOException {
        TimeTableGUI applic = new TimeTableGUI(args);
    } // main

    public TimeTableGUI(String[] args) throws IOException {
        super("TimeTable");
        setUpUIElements();
        if (args.length == 0) {
            outputArea.setText("Input file name at command line cannot be null or blank");
        } else {
            if (args[0] == "") {
                outputArea.setText("Input file name at command line cannot be null or blank");
            } else {
                timeTable = new TimeTable(args);
            }
        }
    } //TimeTableGUI


    private void setUpUIElements() {
        // Create Scrolling Text Area in Swing
        outputArea = new JTextArea("", 20, 100);
        outputArea.setLineWrap(true);
        outputArea.setEditable(false);
        scrollbar = new JScrollPane(outputArea);
        scrollbar.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollbar.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

        FlowLayout flowLayout1 = new FlowLayout();
        setLayout(flowLayout1);
        add(labn);
        add(name);
        name.setEditable(true);
        add(labd);
        add(day);
        day.setEditable(true);
        add(labsT);
        add(startTime);
        startTime.setEditable(true);
        add(labeT);
        add(endTime);
        endTime.setEditable(true);
        add(labwP);
        add(weekPattern);
        weekPattern.setEditable(true);
        add(labl);
        add(location);
        location.setEditable(true);
        add(labrS);
        add(roomSize);
        roomSize.setEditable(true);
        add(labcS);
        add(classSize);
        classSize.setEditable(true);
        add(labs);
        add(staff);
        staff.setVisible(true);
        add(labdep);
        add(department);
        department.setEditable(true);
        add(lookup);
        lookup.addActionListener(this);
        add(add);
        add.addActionListener(this);
        add(remove);
        remove.addActionListener(this);
        add(update);
        update.addActionListener(this);
        setVisible(true);
        add(writeToFile);
        writeToFile.addActionListener(this);
        setVisible(true);

        add(writeToHTMLFile);
        writeToHTMLFile.addActionListener(this);
        setVisible(true);

        blankDisplay();


        add(scrollbar);
        setSize(720, 200);
    } //setUpUIElements

    public void actionPerformed(ActionEvent event) {

        addEntry(event);

        lookUpEntry(event);

        removeEntry(event);

        updateEntry(event);

        writeToFile(event);

        writeToHTMLFile(event);
    } //actionPerformed

    private void writeToHTMLFile(ActionEvent event) {
        if (event.getSource() == writeToHTMLFile) {
            String writeToFileMessage = timeTable.writeToHTMLFile();
            outputArea.setText(writeToFileMessage);
        }
    } //writeToHTMLFile

    private void writeToFile(ActionEvent event) {
        if (event.getSource() == writeToFile) {
            String writeToFileMessage = timeTable.writeToFile();
            outputArea.setText(writeToFileMessage);
        }
    } //writeToFile

    private void updateEntry(ActionEvent event) {
        if (event.getSource() == update) {

            String n = name.getText();
            String d = day.getText();
            String sT = startTime.getText();
            String eT = endTime.getText();
            String wP = weekPattern.getText();
            String l = location.getText();
            String rS = roomSize.getText();
            String cS = classSize.getText();
            String s = staff.getText();
            String dep = department.getText();
            boolean valid = validateFields(n, d, sT, eT, wP, l, rS, cS, s, dep);
            if (valid) {
                Entry e = new Entry(n, d, sT, eT, wP, l, rS, cS, s, dep);
                String updateMessage = timeTable.updateEntry(e);
            }
            outputArea.setText("Record Updated");
            blankDisplay();

        }
    } //updateEntry

    private void removeEntry(ActionEvent event) {
        if (event.getSource() == remove) {
            String n = name.getText();
            String result = timeTable.removeEntry(n);
            timeTable.removeEntry(name.getText());
            outputArea.setText(result);
            blankDisplay();
        }
    } //removeEntry

    private void lookUpEntry(ActionEvent event) {
        if (event.getSource() == lookup) {
            String n = name.getText();
            if (null == n || "".equals(n)) {
                outputArea.setText("Module name can not be null or blank");
            } else {
                String result = timeTable.lookupEntry(n);
                outputArea.setText(result);
            }
            blankDisplay();
        }
    } //lookUpEntry

    private void addEntry(ActionEvent event) {
        if (event.getSource() == add) {

            String n = name.getText();
            String d = day.getText();
            String sT = startTime.getText();
            String eT = endTime.getText();
            String wP = weekPattern.getText();
            String l = location.getText();
            String rS = roomSize.getText();
            String cS = classSize.getText();
            String s = staff.getText();
            String dep = department.getText();
            boolean valid = validateFields(n, d, sT, eT, wP, l, rS, cS, s, dep);
            if (valid) {
                Entry e = new Entry(n, d, sT, eT, wP, l, rS, cS, s, dep);
                String addEntryResult = timeTable.addEntry(e);
                outputArea.setText(addEntryResult);
            }
            blankDisplay();

        }
    } //addEntry

    private boolean validateFields(String n, String d, String sT, String eT, String wP, String l, String rS, String cS, String s, String dep) {
        if (isBlank(n)) {
            outputArea.setText("Module Name can't be blank");
            return false;
        } else if (isBlank(sT)) {
            outputArea.setText("Start time can't be blank");
            return false;
        } else if (isBlank(eT)) {
            outputArea.setText("End time can't be blank");
            return false;
        } else if (isBlank(cS)) {
            outputArea.setText("Class size can't be blank");
            return false;
        } else if (isBlank(rS)) {
            outputArea.setText("Room size can't be blank");
            return false;

        } else {
            if (!isBlank(sT) && !isBlank(eT)) {
                String[] startTimeStrings = sT.split(":");
                String[] endTimeStrings = eT.split(":");
                if (isNumber(startTimeStrings[0]) && isNumber(endTimeStrings[0])) {
                    int startTimeHr = Integer.parseInt(startTimeStrings[0]);
                    int endTimeHr = Integer.parseInt(endTimeStrings[0]);
                    if (startTimeHr > 0 && startTimeHr < 24 && endTimeHr > 0 && endTimeHr < 24) {
                        if (endTimeHr < startTimeHr) {
                            outputArea.setText("End time can't be before start time");
                            return false;
                        }
                    } else {
                        outputArea.setText("Enter valid values for start and end time  as 10:10 format");
                        return false;
                    }
                }
            }

            if (isNumber(cS) && isNumber(rS)) {
                return true;
            }
        }
        return true;
    } //validateFields

    private boolean isNumber(String str) {
        try {
            Integer.parseInt(str);
            return true;

        } catch (NumberFormatException ne) {
            outputArea.setText("Start time / End time / Room size / Class size must be numbers");
            return false;
        }
    } //isNumber

    private boolean isBlank(String str) {
        return null == str || "".equals(str);
    } //isBlank

    public void blankDisplay() {
        name.setText("");
        day.setText("");
        startTime.setText("");
        startTime.setText("");
        endTime.setText("");
        weekPattern.setText("");
        location.setText("");
        roomSize.setText("");
        classSize.setText("");
        staff.setText("");
        department.setText("");

    } //blankDisplay
}