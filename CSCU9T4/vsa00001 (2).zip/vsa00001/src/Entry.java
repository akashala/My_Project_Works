public class Entry {
    private String name;
    private String day;
    private String startTime;
    private String endTime;
    private String weekPattern;
    private String location;
    private String roomSize;
    private String classSize;
    private String staff;
    private String department;

    public Entry(String n, String d, String sT, String eT, String wP, String l, String rS, String cS, String s, String dep) {
        name = n;
        day = d;
        startTime = sT;
        endTime = eT;
        weekPattern = wP;
        location = l;
        roomSize = rS;
        classSize = cS;
        staff = s;
        department = dep;
    } //constructor


    public String getName() {

        return name;
    } //getName

    public String getDay() {
        return day;
    } //getDay

    public String getStartTime() {

        return startTime;
    } //getStartTime

    public String getEndTime() {

        return endTime;
    } //getEndTime

    public String getWeekPattern() {

        return weekPattern;
    } //getWeekPattern

    public String getLocation() {

        return location;
    } //getLocation

    public String getRoomSize() {

        return roomSize;
    } //getRoomSize

    public String getClassSize() {

        return classSize;
    } //getClassSize

    public String getStaff() {

        return staff;
    } //getStaff

    public String getDepartment() {

        return department;
    } // getDepartment

    public String toString() {
        String result = getName() + "\t" +
                getDay() + "\t" +
                getStartTime() + "\t" +
                getEndTime() + "\t" +
                getWeekPattern() + "\t" +
                getLocation() + "\t" +
                getRoomSize() + "\t" +
                getClassSize() + "\t" +
                getStaff() + "\t" +
                getDepartment();
        return result;
    } //toString
} // Entry