public class ComputerLab extends Entry {
    protected String type = "Computer Lab";


    public ComputerLab(String n, String d, String sT, String eT, String wp, String l, String rS, String cS, String s, String dep) {
        super(n, d, sT, eT, wp, l, rS, cS, s, dep);
    } //constructor

    public String getType() {
        return type;
    } //getType

    public String toString() {
        String result = (getType()) + "\t" + super.toString();
        if (Integer.parseInt(getClassSize()) > Integer.parseInt(getRoomSize())) {
            result += "\t class size is more than room size. \n";
        }
        return result.toLowerCase();
    } //toString
}//ComputerLab