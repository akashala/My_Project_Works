public class Lecture extends Entry {

    protected String type = "Lecture";


    public Lecture(String n, String d, String sT, String eT, String wp, String l, String rS, String cS, String s, String dep) {
        super(n, d, sT, eT, wp, l, rS, cS, s, dep);
    } //constructor

    public String getType() {
        return type;
    } //getType

    public String toString() {
        String result = (getType()) + "\t" + super.toString() + "\n";
        return result.toUpperCase();
    } //toString
}//Lecture