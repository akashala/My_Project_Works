public class Seminar extends Entry {
    protected String type = "Seminar";


    public Seminar(String n, String d, String sT, String eT, String wp, String l, String rS, String cS, String s, String dep) {
        super(n, d, sT, eT, wp, l, rS, cS, s, dep);
    } //constructor

    public String getType() {
        return type;
    } //getType

    public String toString() {

        String result = (getType()) + "\t" + super.toString();
        if (isClassSizeLessThanHalfOfRoomSize()) {
            result += "\t class size is less than half of the room size. \n";
        } else if (isClassSize10PercentMoreThanRoomSize()) {
            result += "\t class size is 10 % more than the room size. \n";
        }
        return result.toLowerCase();
    } //toString

    private boolean isClassSize10PercentMoreThanRoomSize() {

        if (getIntClassSize() > (getIntRoomSize() + getIntRoomSize() * 10 / 100)) {
            return true;
        }
        return false;
    } //isClassSize10PercentMoreThanRoomSize

    private boolean isClassSizeLessThanHalfOfRoomSize() {

        return getIntClassSize() < (getIntRoomSize() / 2);
    } //isClassSizeLessThanHalfOfRoomSize

    private int getIntClassSize() {
        if (getClassSize() != null && getClassSize() != "") {
            return Integer.parseInt(getClassSize());
        } else {
            return 0;
        }
    } //getIntClassSize

    private int getIntRoomSize() {
        if (getRoomSize() != null && getRoomSize() != "") {
            return Integer.parseInt(getRoomSize());
        } else {
            return 0;
        }
    } //getIntRoomSize
}//Seminar