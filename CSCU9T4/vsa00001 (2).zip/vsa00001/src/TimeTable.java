import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class TimeTable {
    private List<Entry> timeTableEntries;
    private String inputFileName;
    private String outFileName;

    public String getInputFileName() {
        return inputFileName;
    } //getInputFileName

    public void setInputFileName(String inputFileName) {
        this.inputFileName = inputFileName;
    } //setInputFileName

    public String getOutFileName() {
        return outFileName;
    } //getOutFileName

    public void setOutFileName(String outFileName) {
        this.outFileName = outFileName;
    } //setOutFileName

    public TimeTable(String[] args) throws FileNotFoundException {
        String path = System.getProperty("user.dir");
        path = path + "/";
        timeTableEntries = new ArrayList<>();
        inputFileName = args[0];
        if (args.length > 1) {
            outFileName = args[1];
        }

        File text = new File(path + inputFileName);

        Scanner scanner = new Scanner(text);

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] columns = line.split("\t");
            String name, day, startTime, endTime, weekPattern, location, roomSize, classSize, staff, department;
            name = columns[0];
            day = columns[1];
            startTime = columns[2];
            endTime = columns[3];
            weekPattern = columns[4];
            location = columns[5];
            roomSize = columns[6];
            classSize = columns[7];
            staff = columns[8];
            department = columns[9];

            CreateAppropriateObject(name, day, startTime, endTime, weekPattern, location, roomSize, classSize, staff, department);
        }
    } //TimeTable

    private void CreateAppropriateObject(String name, String day, String startTime, String endTime, String weekPattern, String location, String roomSize, String classSize, String staff, String department) {
        Seminar s;
        Lecture l;
        ComputerLab cl;
        if (name.contains(".S") || name.contains(".s")) {
            s = new Seminar(name, day, startTime, endTime, weekPattern, location, roomSize, classSize, staff, department);
            timeTableEntries.add(s);
        } else if (name.contains(".L") || name.contains(".l")) {
            l = new Lecture(name, day, startTime, endTime, weekPattern, location, roomSize, classSize, staff, department);
            timeTableEntries.add(l);
        } else if (name.contains(".CL") || name.contains(".cl")) {
            cl = new ComputerLab(name, day, startTime, endTime, weekPattern, location, roomSize, classSize, staff, department);
            timeTableEntries.add(cl);
        } else {
            Entry e = new Entry(name, day, startTime, endTime, weekPattern, location, roomSize, classSize, staff, department);
            timeTableEntries.add(e);
        }
    } //CreateAppropriateObject

    public String addEntry(Entry e) {

        ListIterator<Entry> iter = timeTableEntries.listIterator();
        while (iter.hasNext()) {
            Entry current = iter.next();
            if (current.getName().equalsIgnoreCase(e.getName()) &&
                    current.getDay().equalsIgnoreCase(e.getDay()) &&
                    current.getStartTime().equalsIgnoreCase(e.getStartTime()) &&
                    current.getEndTime().equalsIgnoreCase(e.getEndTime()) &&
                    current.getWeekPattern().equalsIgnoreCase(e.getWeekPattern())) {
                return "Duplicate entries are not allowed.";
            }
        }
        CreateAppropriateObject(e.getName(), e.getDay(), e.getStartTime(), e.getEndTime(), e.getWeekPattern(), e.getLocation(), e.getRoomSize(), e.getClassSize(), e.getStaff(), e.getDepartment());
        return "Record Added";
    } //addEntry


    public String lookupEntry(String n) {
        ListIterator<Entry> iter = timeTableEntries.listIterator();
        String result = "Object Type \t Name \t Day\t Start Time \t End Time \t Week Pattern \t Location \t Room Size \t Class Size \t Staff \t Department \tComments \n";
        String noEntriesFoundText = "No entries found";
        boolean entriesFound = false;
        while (iter.hasNext()) {
            Entry current = iter.next();
            if (current.getName().toUpperCase().contains(n.toUpperCase())) {
                entriesFound = true;
                result += current.toString() + "\n";
            }
        }

        return entriesFound ? result : noEntriesFoundText;
    } //lookupEntry

    public String removeEntry(String name) {
        ListIterator<Entry> iter = timeTableEntries.listIterator();
        while (iter.hasNext()) {
            Entry current = iter.next();
            if (name.equalsIgnoreCase(current.getName())) {
                timeTableEntries.remove(current);
                return "Entry removed";
            }
        }
        return "Entry not found";
    } //removeEntry

    public String updateEntry(Entry e) {
        ListIterator<Entry> iter = timeTableEntries.listIterator();
        while (iter.hasNext()) {
            Entry current = iter.next();
            if (e.getName().equalsIgnoreCase(current.getName())) {
                timeTableEntries.remove(current);
                timeTableEntries.add(e);
                return "Entry updated.";
            }
        }
        return "Entry doesn't exist";
    } //updateEntry

    public String writeToFile() {
        if (null == outFileName || "".equals(outFileName))
            return "Output file name not provided at command line";
        try {
            String line;
            FileReader fileReader =
                    new FileReader(getInputFileName());

            BufferedReader bufferedReader =
                    new BufferedReader(fileReader);

            FileWriter fileWriter =
                    new FileWriter(getOutFileName());
            BufferedWriter bufferedWriter =
                    new BufferedWriter(fileWriter);

            while ((line = bufferedReader.readLine()) != null) {
                bufferedWriter.write(line);
                bufferedWriter.newLine();
            }
            bufferedReader.close();
            bufferedWriter.close();
        } catch (IOException ex) {
            System.out.println(
                    "Error writing to file '");
        }
        return "Written timetable entries to output.txt";
    } //writeToFile

    public String writeToHTMLFile() {
        if (null == outFileName || "".equals(outFileName))
            return "Output file name not provided at command line";
        try {
            ListIterator<Entry> iter = timeTableEntries.listIterator();

            String htmlStart = "<html><head>\n" +
                    "  <title>Time Table</title>\n" +
                    "</head>" +
                    "<Body><table style=\"width:100%\">";

            String tableHeader = "<tr>\n" +
                    "    <th>Name</th>" +
                    "    <th>Day</th>" +
                    "    <th>Start Time</th>" +
                    "    <th>End Time</th>" +
                    "    <th>Week Pattern</th>" +
                    "    <th>Location</th>" +
                    "    <th>Room Size</th>" +
                    "    <th>Class Size</th>" +
                    "    <th>Staff</th>" +
                    "    <th>Department</th>" +
                    "  </tr>";
            String htmlEnd = "</Table></Body></Html>";

            String rowStart = "<tr>";
            String tabData = "<td>";
            String rowend = "</tr>";
            String tabDataEnd = "</td>";

            FileWriter fileWriter =
                    new FileWriter(getOutFileName());
            BufferedWriter bufferedWriter =
                    new BufferedWriter(fileWriter);
            bufferedWriter.write(htmlStart);
            bufferedWriter.write(tableHeader);

            while (iter.hasNext()) {
                bufferedWriter.write(rowStart);
                Entry current = iter.next();

                bufferedWriter.write(tabData);
                bufferedWriter.write(current.getName());
                bufferedWriter.write(tabDataEnd);

                bufferedWriter.write(tabData);
                bufferedWriter.write(current.getDay());
                bufferedWriter.write(tabDataEnd);

                bufferedWriter.write(tabData);
                bufferedWriter.write(current.getStartTime());
                bufferedWriter.write(tabDataEnd);

                bufferedWriter.write(tabData);
                bufferedWriter.write(current.getEndTime());
                bufferedWriter.write(tabDataEnd);

                bufferedWriter.write(tabData);
                bufferedWriter.write(current.getWeekPattern());
                bufferedWriter.write(tabDataEnd);

                bufferedWriter.write(tabData);
                bufferedWriter.write(current.getLocation());
                bufferedWriter.write(tabDataEnd);

                bufferedWriter.write(tabData);
                bufferedWriter.write(current.getRoomSize());
                bufferedWriter.write(tabDataEnd);

                bufferedWriter.write(tabData);
                bufferedWriter.write(current.getClassSize());
                bufferedWriter.write(tabDataEnd);

                bufferedWriter.write(tabData);
                bufferedWriter.write(current.getStaff());
                bufferedWriter.write(tabDataEnd);

                bufferedWriter.write(tabData);
                bufferedWriter.write(current.getDepartment());
                bufferedWriter.write(tabDataEnd);
                bufferedWriter.write(rowend);
                bufferedWriter.newLine();
            }
            bufferedWriter.write(htmlEnd);

            bufferedWriter.close();
        } catch (IOException ex) {
            System.out.println(
                    "Error writing to html file '");
        }
        return "Written timetable entries to output.html";
    } //writeToHTMLFile
}