1. A brief summary of the completed functionality of your program.

 - This application works using JavaSwing GUI application helps to searching the TimeTable by Module name.

 - src  folder contains all the class files.

 - As we have 3 different types of entries in the time table
   I have created an "Entry" super class and "Lecture", "Seminar", "ComputerLab" subclasses.

 - A new entry can be added using the "Add" button.

 - A entry will be removed by using "remove" button.

 - You can update the entry by its module name and using "update" button.

 - Look up entries by lookup button.

 - Validations

 - Write to File: This button takes 2nd command line argument as the name of file to write contents to output.txt.

 - Write to HTML output files: This button takes 2nd command line argument as the the name of file to write contents to .html file.

 - The Start Time and End Time will in 24 hours format and if end time is before start time it prints an error message saying "End time can't be before start time".

 - The room size and class size it only takes integers if we enter anything else rather than int it prints an error message saying "Enter valid values for start and end time  as 10:10 format".

 - If the Module name is blank then it's prints "Module Name can't be blank".

 - If the Start Time is blank then it's prints "Start Time can't be blank".

 - If the End Time is blank then it's prints "End Time can't be blank".

 - If the Class Size is blank then it's prints "Class Size can't be blank".

 - If the Room Size is blank then it's prints "Room Size can't be blank".

 - If you press lookup button without entering the module name than it prints a message saying "Module name can not be null or blank".

 - If you press Write to output file button without passing the arguments output.tx than it prints a message saying "Output file name not provided at command line".

 - If you press Write to HTML output file button without passing the arguments .html than it prints a message saying "Output file name not provided at command line".

 - Entries are uniquely identified by name, day, start time, end time and week pattern. It doesn't allow any duplicate entries.

 - A scroll bar is added in vertical to see the data.

 - The input file with data reads in a tab separated file format.

 - I constructed the GUI to browse and it amend the data.

 - I wrote a HTML file to allow the data to display in a web browser.

 - It also allows the user to browse the directory by searching Module Name.

 - Application reads the command line argument as input file and read the contains into list of objects. While creating the list
   if the name of the module contains .S or .s creates the entry as "Seminar", if module name contains .L or .l creates the entry as "Lecture"
   and if module name contains .CL or .cl creates the entry as "ComputerLab".

 - All the Lecture data prints in ALL Capitals.

 - All the ComputerLabs data prints in lower case, if the class size exceeds the room size than it prints a message saying "class size is more than room size.".

 - All the Seminar data prints in lower case, if the class size is less than half of the room size than it prints "class size is less than half of the room size" or if class size is 10 % more than the room size than it prints "class size is 10 % more than the room size".

2. Your object model and the decisions you made in constructing this.

 - Object model file is also included in the zip file (file name is: Object Model.pdf)

 - There is complete class diagram scan copy in the zip file.

 - For Super class all sub classes there is a toString method.

 - In Entry class toString method gives the result of getName, getDay, getStartTime, getEndTime, getWeekPattern, getLocation, getRoomSize, getClassSize, getStaff and getDepartment.

 - In Seminar class toString method gives the result of getType and validations for class size and room size goes there.

 - In Lecture class toString method gives the result of getType and it prints all lectures in Uppercase over there.

 - In ComputerLab class toString method gives the result of getType and validations for class size and room size if class size is more than room size we get a an error message.

 - If you press "Write to output file" than it creates a output.txt and data goes in that.

 - If you want to get html file than change argument to .html and press the "Write to HTML output file" it creates a .html file and the data prints in the browser.